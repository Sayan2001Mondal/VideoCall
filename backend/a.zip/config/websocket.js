const {WebSocketServer} = require("ws")
const socketHandler = require("../socket/socketHandler")


function setupWebSocket(server){
    const wss = new WebSocketServer({server})

    wss.on("connection", (ws) => {
        console.log("User Connected");

        socketHandler(ws)
    })

    
}
module.exports = setupWebSocket
