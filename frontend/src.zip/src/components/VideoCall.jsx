"use client";

import useWebRTC from "../hooks/useWebRTC";

export default function VideoCall({ ws, roomId }) {
  const { localVideoRef, remoteVideoRef, startCall } =
    useWebRTC(ws, roomId);

  return (
    <div style={{ marginTop: 20 }}>
      <h2>Video Call</h2>

      <div style={{ display: "flex", gap: 20 }}>
        <video
          ref={localVideoRef}
          autoPlay
          muted
          playsInline
          width="300"
          style={{ background: "black" }}
        />

        <video
          ref={remoteVideoRef}
          autoPlay
          playsInline
          width="300"
          style={{ background: "black" }}
        />
      </div>

      <button onClick={startCall}>
        Start Call
      </button>
    </div>
  );
}