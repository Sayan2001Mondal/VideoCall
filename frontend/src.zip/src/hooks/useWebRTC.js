import { useEffect, useRef } from "react";

export default function useWebRTC(ws, roomId) {
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);

  const peerConnection = useRef(null);

  useEffect(() => {
    if (!ws.current) return;

    // Create Peer Connection
    peerConnection.current = new RTCPeerConnection({
      iceServers: [
        {
          urls: "stun:stun.l.google.com:19302",
        },
      ],
    });

    // Get Camera + Mic
    navigator.mediaDevices
      .getUserMedia({
        video: true,
        audio: true,
      })
      .then((stream) => {
        // Show local video
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        // Add tracks to peer connection
        stream.getTracks().forEach((track) => {
          peerConnection.current.addTrack(track, stream);
        });
      })
      .catch((err) => {
        console.error("Media Error:", err);
      });

    // Receive remote stream
    peerConnection.current.ontrack = (event) => {
      console.log("Remote stream received");

      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = event.streams[0];
      }
    };

    // ICE Candidate Handling
    peerConnection.current.onicecandidate = (event) => {
      if (event.candidate) {
        ws.current.send(
          JSON.stringify({
            type: "candidate",
            roomId,
            candidate: event.candidate,
          })
        );
      }
    };

    // Handle Incoming WebSocket Messages
    const handleMessage = async (event) => {
      const data = JSON.parse(event.data);

      console.log("WS MESSAGE:", data);

      try {
        // OFFER
        if (data.type === "offer") {
          console.log("Received Offer");

          await peerConnection.current.setRemoteDescription(
            new RTCSessionDescription(data.offer)
          );

          const answer = await peerConnection.current.createAnswer();

          await peerConnection.current.setLocalDescription(answer);

          ws.current.send(
            JSON.stringify({
              type: "answer",
              roomId,
              answer,
            })
          );
        }

        // ANSWER
        if (data.type === "answer") {
          console.log("Received Answer");

          await peerConnection.current.setRemoteDescription(
            new RTCSessionDescription(data.answer)
          );
        }

        // ICE CANDIDATE
        if (data.type === "candidate") {
          console.log("Received Candidate");

          await peerConnection.current.addIceCandidate(
            new RTCIceCandidate(data.candidate)
          );
        }
      } catch (err) {
        console.error("WebRTC Error:", err);
      }
    };

    // Add WS listener
    ws.current.addEventListener("message", handleMessage);

    // Cleanup
    return () => {
      ws.current?.removeEventListener("message", handleMessage);

      peerConnection.current?.close();
    };
  }, [ws, roomId]);

  // Start Call
  const startCall = async () => {
    try {
      console.log("Starting Call");

      const offer = await peerConnection.current.createOffer();

      await peerConnection.current.setLocalDescription(offer);

      ws.current.send(
        JSON.stringify({
          type: "offer",
          roomId,
          offer,
        })
      );
    } catch (err) {
      console.error("Start Call Error:", err);
    }
  };

  return {
    localVideoRef,
    remoteVideoRef,
    startCall,
  };
}